var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});

exports['default'] = function (context) {
	try {

		var document = sketch.fromNative(context.document);
		var dialog = ui.dialog('合并', '');
		var styles = document.getSharedTextStyles();
		var names = styles.map(function (x) {
			return x.name;
		});
		var checkboxs = [];
		var scrollview = ui.scrollview();
		scrollview.setHasVerticalScroller(true);
		scrollview.setHasHorizontalScroller(true);
		var scrollContent = new layout(0, 0, 300, 600);
		names.forEach(function (x, y) {
			var checkbox = ui.checkbox(false, x, y * 20);
			scrollContent.add(checkbox);
			checkboxs.push(checkbox);
		});
		scrollview.setDocumentView(scrollContent.view());dialog.addAccessoryView(scrollview);
		var to = ui.popupButton(names);

		dialog.addAccessoryView(to);
		var responseCode = dialog.runModal();
		if (responseCode === 1000) {
			var ids = [];
			checkboxs.forEach(function (x, y) {
				if (parseInt(x.stringValue())) {
					ids.push(styles[y].id);
				}
			});
			var toIndex = to.indexOfSelectedItem();
			var toValue = styles[toIndex];
			var _document = dom.getSelectedDocument();
			_document.pages.forEach(function (x) {
				changePage(x, ids, toValue);
			});
		}
	} catch (e) {
		UI.alert('error', e.toString());
	}
};

var sketch = __webpack_require__(1);
var ui = __webpack_require__(2);
var UI = __webpack_require__(3);
var dom = __webpack_require__(4);
var layout = __webpack_require__(5);

function changePage(one, from, to) {

	if (from.indexOf(one.sharedStyleId) > -1) {
		one.sharedStyleId = to.id;
	}
	one.affectedLayer && changePage(one.affectedLayer, from, to);
	one.overrides && one.overrides.forEach(function (y) {
		return changePage(y, from, to);
	});
	one.layers && one.layers.forEach(function (y) {
		return changePage(y, from, to);
	});
}

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var ui = {};

ui.dialog = function (title, info) {
	var dialog = COSAlertWindow.alloc().init();
	dialog.setMessageText(title);
	if (info) {
		dialog.setInformativeText(info);
	}
	dialog.setIcon(null);
	dialog.addButtonWithTitle('OK');
	dialog.addButtonWithTitle('Cancel');
	return dialog;
};

ui.scrollview = function () {
	var view = NSScrollView.alloc().initWithFrame(NSMakeRect(0, 0, 300, 600));
	return view;
};

ui.checkbox = function (status, title, y) {
	var view = NSButton.alloc().initWithFrame(NSMakeRect(0, y, 300, 24));
	view.setButtonType(NSSwitchButton);
	view.setTitle(title);
	if (status == true) {
		view.setState(NSOnState);
	} else {
		view.setState(NSOffState);
	}
	return view;
};

ui.label = function (text) {
	var view = NSTextField.alloc().initWithFrame(NSMakeRect(0, 0, 300, 16));
	view.setStringValue(text);
	view.setBezeled(false);
	view.setDrawsBackground(false);
	view.setEditable(false);
	view.setSelectable(false);
	return view;
};

ui.input = function (text) {
	var view = NSTextField.alloc().initWithFrame(NSMakeRect(0, 0, 300, 24));
	view.setStringValue(text);
	return view;
};

ui.numberInput = function (text) {
	var view = NSTextField.alloc().initWithFrame(NSMakeRect(0, 0, 60, 24));
	var formatter = NSNumberFormatter.alloc().init().autorelease();
	formatter.setNumberStyle(NSNumberFormatterNoStyle);
	view.setFormatter(formatter);
	view.setStringValue(String(text));
	return view;
};

ui.popupButton = function (items) {
	var view = NSPopUpButton.alloc().initWithFrame(NSMakeRect(0, 0, 300, 24));
	items.forEach(function (item) {
		view.addItemWithTitle('');
		view.lastItem().setTitle(item);
	});
	return view;
};

ui.stepper = function (min, max, defaultValue) {
	var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, 300, 24));
	var input = NSTextField.alloc().initWithFrame(NSMakeRect(0, 0, 60, 24));
	input.setEditable(false);
	input.setStringValue(String(defaultValue));
	var stepper = NSStepper.alloc().initWithFrame(NSMakeRect(68, 0, 16, 24));
	stepper.setMaxValue(max);
	stepper.setMinValue(min);
	stepper.setValueWraps(false);
	stepper.setAutorepeat(true);
	stepper.setIntegerValue(defaultValue);
	view.addSubview(input);
	view.addSubview(stepper);
	stepper.setCOSJSTargetFunction(function (sender) {
		input.setStringValue(String(sender.integerValue()));
	});
	return view;
};

module.exports = ui;

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function LayoutView(x, y, width, height) {
    this.prevFrame = NSMakeRect(0, 0, 0, 0);
    this._views = [];
    var _view = NSView.alloc().initWithFrame(NSMakeRect(x, y, width, height == undefined ? 0 : height));
    this.view = function () {
        return _view;
    };
    return this;
}
LayoutView.prototype.add = function (view, layout) {
    if (view instanceof LayoutView) {
        return this.add(view.view(), layout);
    }
    var f = view.frame();
    var newFrame = f;
    if (layout === undefined) {
        //position it under previous element, and resize parent
        this.increaseHeight(f.size.height);
        newFrame = NSMakeRect(f.origin.x, 0, f.size.width, f.size.height);
        view.setFrame(newFrame);
    } else if (layout === "absolute/resize") {
        //position it absolutely, and resize parent if necessary
        var delta = f.size.height - this.height();
        if (delta > 0) {
            this.increaseHeight(delta);
        }
    } else if (layout === "absolute") {
        //just position it absolutely without resizing
    }
    this.prevFrame = newFrame;
    this.view().addSubview(view);
    this._views.push(view);

    return this;
};
LayoutView.prototype.addPadding = function (px) {
    //adds vertical padding at current position
    this.increaseHeight(px);
};
LayoutView.prototype.increaseHeight = function (delta) {
    var f = this.view().frame();

    //resize main view
    this.view().setFrame(NSMakeRect(f.origin.x, f.origin.y, f.size.width, f.size.height + delta));

    //translate each subview
    for (var i = 0; i < this._views.length; ++i) {
        var v = this._views[i];
        f = v.frame();
        v.setFrame(NSMakeRect(f.origin.x, f.origin.y + delta, f.size.width, f.size.height));
    }
    if (this._views.length) {
        //update prevFrame val
        this.prevFrame = this._views[this._views.length - 1].frame();
    }
};
LayoutView.prototype.height = function () {
    if (this._views.length == 0) {
        return 0;
    }
    var f = this._views[0].frame();
    return Math.abs(f.origin.y) + f.size.height;
};
module.exports = LayoutView;

/***/ })
/******/ ]);
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')
